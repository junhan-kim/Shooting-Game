﻿

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Game
{


    // 만들만한거 : 속도 조정
    public partial class Form1 : Form
    {
        int counter;

        int Pan_X; // 판 사이즈
        int Pan_Y;
        int Pan_Width;
        int Pan_Height;
        int Pan_Loc_X;
        int Pan_Loc_Y;

        int Pan_Block_X; // 판 사이즈 (블락 단위)
        int Pan_Block_Y;

        //Random random;
        Dump[,] dump;
        //int BlockIdNow = 0;
        //int BlocksNum = 0;
        //Queue<Blocks> BlocksQueue = new Queue<Blocks>();
        List<Blocks> BlocksList = new List<Blocks>();

        const int Block_Size_X = 20;
        const int Block_Size_Y = 20;
        // 420 x 540  이므로  21 x 27 (블락단위)


        //private Form1.DoubleBufferPanel GamePane;
        public class MyDisplay : Panel
        {
            public MyDisplay()
            {
                this.DoubleBuffered = true;

                SetStyle(ControlStyles.AllPaintingInWmPaint, true);
                SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
                UpdateStyles();

                this.SetStyle(ControlStyles.OptimizedDoubleBuffer | 
                    ControlStyles.UserPaint |
                    ControlStyles.AllPaintingInWmPaint, true  );
                this.UpdateStyles();




                this.BackColor = Color.White;
                this.Location = new Point(0, 0);
                this.Size = new Size(420, 540);

            }
        }
        MyDisplay display = new MyDisplay();
        


        //private class GamePan : System.Windows.Forms.Panel
        //{
        //    public GamePan()
        //    {
        //        this.SetStyle(System.Windows.Forms.ControlStyles.UserPaint, true);
        //        this.SetStyle(System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer | System.Windows.Forms.ControlStyles.AllPaintingInWmPaint, true);
        //        this.SetStyle(System.Windows.Forms.ControlStyles.EnableNotifyMessage, true);
        //    }

        //    protected override void OnNotifyMessage(System.Windows.Forms.Message m)
        //    {
        //        if (m.Msg != 0x0014) // WM_ERASEBKGND == 0X0014
        //        {
        //            base.OnNotifyMessage(m);
        //        }
        //    }
        //}

        public class Dump
        {
            int x;
            int y;
            public int X
            {
                get { return x; }
                set { x = value; }
            }
            public int Y
            {
                get { return y; }
                set { y = value; }
            }
            public bool check { get; set; }

            public Color c;
        }



        public class Block

        {
            Random random;
            public int x { get; set; }
            public int y { get; set; }
            int size_x = Block_Size_X;
            int size_y = Block_Size_Y;
            public Color c;


            public Block(int x, int y)
            {
                this.x = x;
                this.x -= size_x / 2;
                this.y = y;
                random = new Random();
                c = Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255));
            }

            public void Draw(Graphics g)
            {
                //c = Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255));
                //c = Color.Aqua;
                Pen pen = new Pen(c, 5);
                pen.Alignment = System.Drawing.Drawing2D.PenAlignment.Inset;
                g.DrawRectangle(pen, new Rectangle(x, y, size_x, size_y));
                //g.FillRectangle(new SolidBrush(Color.Red), new Rectangle(x, y, size_x, size_y));
            }

        }

        class Blocks
        {
            //int size_x;
            //int size_y;
            public Block[] block { get; set; }
            public int x { get; set; }
            public int y { get; set; }
            public int type { get; set; }
            public int rotType { get; set; }
            //public int size_blocks_x { get; set; }
            public int coreblock_height { get; set; }  // 바닥 기준 높이 (나중에 폐기)

            public int leftLimitBlock_X { get; set; }
            public int rightLimitBlock_X { get; set; }

            public int[] floorBlockX { get; set; }
            public int[] floorBlockY { get; set; }
            public int floorSize;



            public Blocks(int x, int y, int type)
            {
                this.x = x;
                this.y = y;
                this.type = type; // 0 : O미노, 1 : I미노, 2 : T미노, 3 : Z미노, 4 : S미노, 5 : J미노, 6 : L미노 
                rotType = 0;
                block = new Block[4];
                floorBlockX = new int[4];
                floorBlockY = new int[4];

                for (int i = 0; i < block.Length; i++)
                {
                    block[i] = new Block(x, y);
                }

                for (int i = 0; i < floorBlockX.Length; i++)
                {
                    floorBlockX[i] = new int();
                }
                for (int i = 0; i < floorBlockY.Length; i++)
                {
                    floorBlockY[i] = new int();
                }
            }


            public void RefreshBlocksShape()
            {



                switch (type)
                {
                    case 0: // 0 : O미노
                        //block[0] = new Block(x, y);
                        //block[1] = new Block(x + Block_Size_X, y);
                        //block[2] = new Block(x, y + Block_Size_Y);
                        //block[3] = new Block(x + Block_Size_X, y + Block_Size_Y);
                        switch (rotType)
                        {
                            case 0:
                            case 1:
                            case 2:
                            //    coreblock_height = Block_Size_Y * 3;

                            //    block[0].x = x;
                            //    block[0].y = y;
                            //    block[1].x = x + Block_Size_X;
                            //    block[1].y = y;
                            //    block[2].x = x;
                            //    block[2].y = y + Block_Size_Y;
                            //    block[3].x = x + Block_Size_X;
                            //    block[3].y = y + Block_Size_Y;
                            //    leftLimitBlock_X = block[0].x;
                            //    rightLimitBlock_X = block[1].x;

                            //    floorBlockX[0] = block[2].x;
                            //    floorBlockY[0] = block[2].y;
                            //    floorBlockX[1] = block[3].x;
                            //    floorBlockY[1] = block[3].y;


                            //    break;
                            //case 1:
                            //    coreblock_height = Block_Size_Y * 3;

                            //    block[0].x = x;
                            //    block[0].y = y;
                            //    block[1].x = x + Block_Size_X;
                            //    block[1].y = y;
                            //    block[2].x = x;
                            //    block[2].y = y + Block_Size_Y;
                            //    block[3].x = x + Block_Size_X;
                            //    block[3].y = y + Block_Size_Y;
                            //    leftLimitBlock_X = block[0].x;
                            //    rightLimitBlock_X = block[1].x;

                            //    break;
                            //case 2:
                            //    coreblock_height = Block_Size_Y * 3;

                            //    block[0].x = x;
                            //    block[0].y = y;
                            //    block[1].x = x + Block_Size_X;
                            //    block[1].y = y;
                            //    block[2].x = x;
                            //    block[2].y = y + Block_Size_Y;
                            //    block[3].x = x + Block_Size_X;
                            //    block[3].y = y + Block_Size_Y;
                            //    leftLimitBlock_X = block[0].x;
                            //    rightLimitBlock_X = block[1].x;

                            //    break;
                            case 3:
                                coreblock_height = Block_Size_Y * 3;

                                block[0].x = x;
                                block[0].y = y;
                                block[1].x = x + Block_Size_X;
                                block[1].y = y;
                                block[2].x = x;
                                block[2].y = y + Block_Size_Y;
                                block[3].x = x + Block_Size_X;
                                block[3].y = y + Block_Size_Y;
                                leftLimitBlock_X = block[0].x;
                                rightLimitBlock_X = block[1].x;

                                floorBlockX[0] = block[2].x;
                                floorBlockY[0] = block[2].y;
                                floorBlockX[1] = block[3].x;
                                floorBlockY[1] = block[3].y;
                                floorSize = 2;
                                break;
                        }
                        break;
                    case 1: // 1 : I미노
                        //block[0] = new Block(x, y);
                        //block[1] = new Block(x, y + Block_Size_Y);
                        //block[2] = new Block(x, y + Block_Size_Y * 2);
                        //block[3] = new Block(x, y + Block_Size_Y * 3);

                        switch (rotType)
                        {
                            case 0:
                                coreblock_height = Block_Size_Y * 5;

                                block[0].x = x;
                                block[0].y = y;
                                block[1].x = x;
                                block[1].y = y + Block_Size_Y;
                                block[2].x = x;
                                block[2].y = y + Block_Size_Y * 2;
                                block[3].x = x;
                                block[3].y = y + Block_Size_Y * 3;
                                leftLimitBlock_X = block[0].x;
                                rightLimitBlock_X = block[0].x;

                                floorBlockX[0] = block[3].x;
                                floorBlockY[0] = block[3].y;
                                floorSize = 1;
                                break;
                            case 1:
                                coreblock_height = Block_Size_Y * 2;

                                block[0].x = x;
                                block[0].y = y;
                                block[1].x = x + Block_Size_X;
                                block[1].y = y;
                                block[2].x = x + Block_Size_X * 2;
                                block[2].y = y;
                                block[3].x = x + Block_Size_X * 3;
                                block[3].y = y;
                                leftLimitBlock_X = block[0].x;
                                rightLimitBlock_X = block[3].x;

                                floorBlockX[0] = block[0].x;
                                floorBlockY[0] = block[0].y;
                                floorBlockX[1] = block[1].x;
                                floorBlockY[1] = block[1].y;
                                floorBlockX[2] = block[2].x;
                                floorBlockY[2] = block[2].y;
                                floorBlockX[3] = block[3].x;
                                floorBlockY[3] = block[3].y;
                                floorSize = 4;
                                break;
                            case 2:
                                coreblock_height = Block_Size_Y * 2;

                                block[0].x = x;
                                block[0].y = y;
                                block[1].x = x;
                                block[1].y = y - Block_Size_Y;
                                block[2].x = x;
                                block[2].y = y - Block_Size_Y * 2;
                                block[3].x = x;
                                block[3].y = y - Block_Size_Y * 3;
                                leftLimitBlock_X = block[0].x;
                                rightLimitBlock_X = block[0].x;

                                floorBlockX[0] = block[0].x;
                                floorBlockY[0] = block[0].y;
                                floorSize = 1;
                                break;
                            case 3:
                                coreblock_height = Block_Size_Y * 2;

                                block[0].x = x;
                                block[0].y = y;
                                block[1].x = x - Block_Size_X;
                                block[1].y = y;
                                block[2].x = x - Block_Size_X * 2;
                                block[2].y = y;
                                block[3].x = x - Block_Size_X * 3;
                                block[3].y = y;
                                leftLimitBlock_X = block[3].x;
                                rightLimitBlock_X = block[0].x;

                                floorBlockX[0] = block[3].x;
                                floorBlockY[0] = block[3].y;
                                floorBlockX[1] = block[2].x;
                                floorBlockY[1] = block[2].y;
                                floorBlockX[2] = block[1].x;
                                floorBlockY[2] = block[1].y;
                                floorBlockX[3] = block[0].x;
                                floorBlockY[3] = block[0].y;
                                floorSize = 4;
                                break;
                        }
                        break;
                    case 2: // 2 : T미노
                        //block[0] = new Block(x, y);
                        //block[1] = new Block(x - Block_Size_X, y);
                        //block[2] = new Block(x + Block_Size_X, y);
                        //block[3] = new Block(x, y - Block_Size_Y);

                        switch (rotType)
                        {
                            case 0:
                                coreblock_height = Block_Size_Y * 2;

                                block[0].x = x;
                                block[0].y = y;
                                block[1].x = x - Block_Size_X;
                                block[1].y = y;
                                block[2].x = x + Block_Size_X;
                                block[2].y = y;
                                block[3].x = x;
                                block[3].y = y - Block_Size_Y;
                                leftLimitBlock_X = block[1].x;
                                rightLimitBlock_X = block[2].x;

                                floorBlockX[0] = block[1].x;
                                floorBlockY[0] = block[1].y;
                                floorBlockX[1] = block[0].x;
                                floorBlockY[1] = block[0].y;
                                floorBlockX[2] = block[2].x;
                                floorBlockY[2] = block[2].y;
                                floorSize = 3;
                                break;
                            case 1:

                                coreblock_height = Block_Size_Y * 3;

                                block[0].x = x;
                                block[0].y = y;
                                block[1].x = x;
                                block[1].y = y + Block_Size_Y;
                                block[2].x = x;
                                block[2].y = y - Block_Size_Y;
                                block[3].x = x - Block_Size_X;
                                block[3].y = y;
                                leftLimitBlock_X = block[3].x;
                                rightLimitBlock_X = block[0].x;

                                floorBlockX[0] = block[3].x;
                                floorBlockY[0] = block[3].y;
                                floorBlockX[1] = block[1].x;
                                floorBlockY[1] = block[1].y;
                                floorSize = 2;
                                break;
                            case 2:

                                coreblock_height = Block_Size_Y * 3;

                                block[0].x = x;
                                block[0].y = y;
                                block[1].x = x + Block_Size_X;
                                block[1].y = y;
                                block[2].x = x - Block_Size_X;
                                block[2].y = y;
                                block[3].x = x;
                                block[3].y = y + Block_Size_Y;
                                leftLimitBlock_X = block[2].x;
                                rightLimitBlock_X = block[1].x;

                                floorBlockX[0] = block[2].x;
                                floorBlockY[0] = block[2].y;
                                floorBlockX[1] = block[3].x;
                                floorBlockY[1] = block[3].y;
                                floorBlockX[2] = block[1].x;
                                floorBlockY[2] = block[1].y;
                                floorSize = 3;
                                break;
                            case 3:
                                coreblock_height = Block_Size_Y * 3;

                                block[0].x = x;
                                block[0].y = y;
                                block[1].x = x;
                                block[1].y = y - Block_Size_Y;
                                block[2].x = x;
                                block[2].y = y + Block_Size_Y;
                                block[3].x = x + Block_Size_X;
                                block[3].y = y;
                                leftLimitBlock_X = block[1].x;
                                rightLimitBlock_X = block[3].x;

                                floorBlockX[0] = block[2].x;
                                floorBlockY[0] = block[2].y;
                                floorBlockX[1] = block[3].x;
                                floorBlockY[1] = block[3].y;
                                floorSize = 2;
                                break;
                        }
                        break;
                    case 3: // 3 : Z미노
                        //block[0] = new Block(x, y);
                        //block[1] = new Block(x + Block_Size_X, y);
                        //block[2] = new Block(x - Block_Size_X, y - Block_Size_Y);
                        //block[3] = new Block(x, y - Block_Size_Y);
                        //block[0].x = x;
                        //block[0].y = y;
                        //block[1].x = x + Block_Size_X;
                        //block[1].y = y;
                        //block[2].x = x - Block_Size_X;
                        //block[2].y = y - Block_Size_Y;
                        //block[3].x = x;
                        //block[3].y = y - Block_Size_Y;

                        break;
                        //case 4: //  4 : S미노
                        //    block[0] = new Block(x, y);
                        //    block[1] = new Block(x + Block_Size_X, y);
                        //    block[2] = new Block(x - Block_Size_X, y + Block_Size_Y);
                        //    block[3] = new Block(x, y + Block_Size_Y);

                        //    break;
                        //case 5: // 5 : J미노
                        //    block[0] = new Block(x, y);
                        //    block[1] = new Block(x + Block_Size_X, y);
                        //    block[2] = new Block(x, y + Block_Size_Y);
                        //    block[3] = new Block(x, y + Block_Size_Y * 2);

                        //    break;
                        //case 6: // 6 : L미노 
                        //    block[0] = new Block(x, y);
                        //    block[1] = new Block(x - Block_Size_X, y);
                        //    block[2] = new Block(x, y + Block_Size_Y);
                        //    block[3] = new Block(x, y + Block_Size_Y * 2);

                        //    break;
                }
            }

            //public void RefreshBlockShape()
            //{
            //    for(int i=0; i<block.Length; i++)
            //    {
            //        block[i].x = x;
            //        block[i].y = y;
            //    }
            //}



            public void Move(int direction)
            {


            }

            public void Rotate()
            {
            }

            public void Draw(Graphics g)
            {
                for (int i = 0; i < block.Length; i++)
                {
                    block[i].Draw(g);
                }
            }
        }




        //int x = 20;
        //int y = 30;



        //int xPos = 10;
        //int yPos = 0;

        int score = 0;


        // Form1.KeyDown += new KeyEventHandler(Form1_KeyDown);


        public void _SuspendLayout()
        {
            display.SuspendLayout();
        }

        public void _ResumeLayout()
        {
            display.ResumeLayout(false);
        }

        public Graphics _CreateGraphics()
        {
            return display.CreateGraphics();
        }

        public Form1()
        {
            InitializeComponent();

            Controls.Add(display);

            //base.SetStyle(ControlStyles.DoubleBuffer, true);
            //base.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            //base.SetStyle(ControlStyles.ResizeRedraw, true);

            counter = 0;

            Pan_X = display.Width;
            Pan_Y = display.Height;
            Pan_Width = display.Width;
            Pan_Height = display.Height;
            Pan_Loc_X = display.Location.X;
            Pan_Loc_Y = display.Location.Y;


            Pan_Block_X = Pan_X / Block_Size_X;
            Pan_Block_Y = Pan_Y / Block_Size_Y;

            dump = new Dump[Pan_Block_X,Pan_Block_Y];
            for (int y = 0; y < Pan_Block_Y; y++)
            {
                for (int x = 0; x < Pan_Block_X; x++)
                {
                    dump[x, y] = new Dump();
                }
            }
            for (int y = 0; y < Pan_Block_Y; y++)
            {
                for (int x = 0; x < Pan_Block_X; x++)
                {
                    dump[x, y].X = Pan_Loc_X + x * Block_Size_X;
                    dump[x, y].Y = Pan_Loc_Y + y * Block_Size_Y;
                }
            }
            //textBox1.Text = dump[Pan_Block_X-1, Pan_Block_Y - 1].y.ToString();

            timer1.Start();
            timer2.Start();

            
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Left)
            //{
            //    textBox1.Text = "sfsff";
            //    Blocks blocks = BlocksQueue.Peek();
            //    blocks.RefreshBlocksShape();
            //    blocks.Draw(GamePan.CreateGraphics());
            //}
        }

        void MakeBlock()
        {
            //SolidBrush myBrush = new SolidBrush(Color.Red);
            //Graphics formGraphics = this.CreateGraphics();
            //formGraphics.FillRectangle(myBrush, new Rectangle(0, 0, 200, 300));
            //myBrush.Dispose();
            //formGraphics.Dispose();
        }

        void DrawRectangle()
        {
            System.Drawing.Pen myPen = new System.Drawing.Pen(System.Drawing.Color.Red);
            System.Drawing.Graphics formGraphics;
            formGraphics = this.CreateGraphics();
            formGraphics.DrawRectangle(myPen, new Rectangle(0, 0, 300, 300));
            myPen.Dispose();
            formGraphics.Dispose();
        }

        //void InitGame()
        //{
        //    score = 0;
        //}

        private void Form1_Load(object sender, EventArgs e)
        {
            DrawRectangle();
        }

        private void GamePane_Paint(object sender, PaintEventArgs e)
        {
            //Graphics g = GamePane.CreateGraphics();
            //for (int x = Block_Size_X; x < GamePane.Width; x+=Block_Size_X)
            //{
            //    g.DrawLine(new Pen(Color.Black), new Point(x,0), new Point(x,GamePane.Height));
            //}
            //for (int y = Block_Size_Y; y < GamePane.Height; y+= Block_Size_X)
            //{
            //    g.DrawLine(new Pen(Color.Black), new Point(0, y), new Point(GamePane.Width, y));
            //}
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Graphics g = GamePan.CreateGraphics();
            //g.Clear(Color.White);
            // 블록 만들기





        }

        private void Make_Tick(object sender, EventArgs e)
        {

        }
        private void Drop_Tick(object sender, EventArgs e)
        {

        }
        private void timer2_Tick(object sender, EventArgs e)
        {

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            _SuspendLayout();

            Random random = new Random();
            Blocks blocks = new Blocks(Block_Size_X * 10, -10, random.Next(0, 3)); // 7
            //BlocksNum++;
            BlocksList.Add(blocks);

            //blocks.RefreshBlocksShape();

            _ResumeLayout();
        }

        private void timer2_Tick_1(object sender, EventArgs e)
        {
            SuspendLayout();

            counter++;
            if (counter == 100)
            {
                if(timer2.Interval >=100) timer2.Interval -= 50;
                counter = 0;
            }
  

            bool bNext = false;
            Graphics g = _CreateGraphics();
            g.Clear(Color.White);
            List<int>blockIndex = new List<int>();
            

            if (BlocksList.Count != 0)
            {
                for (int j = 0; j < BlocksList.Count; j++)
                {
                    //Array<Blocks> QueueToArray = BlocksQueue.ToArray()[BlocksQueue.Count];
                    for (int i = 0; i < BlocksList[j].floorSize; i++)
                    {
                        if (BlocksList[j].floorBlockY[i] == Pan_Loc_Y + Pan_Y - Block_Size_Y)
                        {
                            bNext = true;
                            blockIndex.Add(j);
                        }
                       



                        int tmpX = BlocksList[j].floorBlockX[i] / Block_Size_X;
                        int tmpY = (BlocksList[j].floorBlockY[i] + Block_Size_Y) / Block_Size_Y;
                        if (tmpY < Pan_Block_Y)
                        {
                            //textBox1.Text = tmpX.ToString();
                            //textBox2.Text = tmpY.ToString();
                            if (dump[tmpX, tmpY].check == true)
                            {
                                bNext = true;
                                blockIndex.Add(j);
                            }

                        }
                    }
                    //if (bNext == true) break;
                }
                //for (int i = 0; i < BlocksQueue.Peek().floorSize; i++)
                //{
                //    if (BlocksQueue.Peek().floorBlockY[i] == Pan_Loc_Y + Pan_Y - Block_Size_Y)
                //    { bNext = true; }



                //    int tmpX = BlocksQueue.Peek().floorBlockX[i] / Block_Size_X;
                //    int tmpY = (BlocksQueue.Peek().floorBlockY[i] + Block_Size_Y) / Block_Size_Y;
                //    if (tmpY < Pan_Block_Y)
                //    {
                //        textBox1.Text = tmpX.ToString();
                //        textBox2.Text = tmpY.ToString();
                //        if (dump[tmpX, tmpY].check == true)
                //        { bNext = true; }

                //    }
                //}

                //switch (BlocksQueue.Peek().floorSize)
                //{

                //    case 1:
                //        if(bNext == true)
                //        {

                //        }


                //        break;
                //    case 2:




                //            break;
                //    case 3:
                //        break;
                //    case 4:
                //        break;

                //if (BlocksQueue.Peek().floorBlockY == GamePane.Location.Y + Pan_Y - Block_Size_Y)
                //{
                if (bNext == true)
                {
                    for (int k = 0; k < blockIndex.Count; k++)
                    {
                        int j = blockIndex[k];
                        textBox1.Text = j.ToString();
                        for (int y = 0; y < Pan_Block_Y; y++)
                        {
                            for (int x = 0; x < Pan_Block_X; x++)
                            {
                                if ((dump[x, y].X == BlocksList[j].x) && (dump[x, y].Y == BlocksList[j].y))
                                {
                                    for (int i = 0; i < 4; i++)
                                    {
                                        int dumpTmpX = BlocksList[j].block[i].x / Block_Size_X;
                                        int dumpTmpY = BlocksList[j].block[i].y / Block_Size_Y;
                                        dump[dumpTmpX, dumpTmpY].check = true;
                                        dump[dumpTmpX, dumpTmpY].c = BlocksList[0].block[i].c;

                                        //textBox1.Text = dumpTmpX.ToString();
                                        //textBox2.Text = dumpTmpY.ToString();
                                    }

                                }
                            }
                        }
                        BlocksList.RemoveAt(j);
                        //BlocksQueue.Dequeue();
                        //bNext = true;
                    }
                    
                }

            }





            foreach (var item in BlocksList)
            {


                item.y += 10;
                item.RefreshBlocksShape();
                //switch(item.type)
                //{
                //    case 0:

                //        break;
                //    case 1:
                //        break;

                //}
                item.Draw(_CreateGraphics());
            }

            _ResumeLayout();
        }

        private void Form1_KeyDown_1(object sender, KeyEventArgs e)
        {
            _SuspendLayout();

            if (BlocksList.Count != 0)
            {
                Blocks blocks = BlocksList[0];
                Graphics g = _CreateGraphics();
                g.Clear(Color.White);


                if (e.KeyCode == Keys.Up)
                {
                    if (blocks.rotType <= 2 && blocks.rotType >= 0) blocks.rotType++;
                    else blocks.rotType = 0;

                    blocks.RefreshBlocksShape();

                    if (blocks.leftLimitBlock_X < Pan_Loc_X)
                    {

                        //textBox1.Text = blocks.leftLimitBlock_X.ToString();
                        blocks.x = Pan_Loc_X - blocks.leftLimitBlock_X;
                        blocks.RefreshBlocksShape();
                    }
                    if (blocks.rightLimitBlock_X > Pan_Loc_X + Pan_Width - Block_Size_X)
                    {
                        //textBox1.Text = (GamePane.Location.X + GamePane.Width - (blocks.rightLimitBlock_X - (GamePane.Location.X + GamePane.Width))).ToString();
                        blocks.x = 2 * (Pan_Loc_X + Pan_Width - Block_Size_X) - blocks.rightLimitBlock_X; // rightLimit은 440정도로 존나 큰 값임 (오차값으로 수정해야함)
                        blocks.RefreshBlocksShape();
                    }

                    blocks.Draw(_CreateGraphics());
                }
                //else if (e.KeyCode == Keys.Right)
                //{
                //    if (blocks.rotType >= 1 && blocks.rotType <= 3) blocks.rotType--;
                //    else blocks.rotType = 3;
                //    blocks.RefreshBlocksShape();
                //    blocks.Draw(GamePane.CreateGraphics());
                //}
                if (e.KeyCode == Keys.Space)  // 스페이스누르면 바닥으로 딱  (수정 요망)
                {

                    bool bNext = false;
                    int cnt = 0;
             
                    while ((bNext == false)  )
                    {
                        
                        //Array<Blocks> QueueToArray = BlocksQueue.ToArray()[BlocksQueue.Count];
                        for (int i = 0; i < BlocksList[0].floorSize; i++)
                        {
                            if (BlocksList[0].floorBlockY[i] == Pan_Loc_Y + Pan_Y - Block_Size_Y)
                            { bNext = true; break; }



                            int tmpX = BlocksList[0].floorBlockX[i] / Block_Size_X;
                            int tmpY = (BlocksList[0].floorBlockY[i] + Block_Size_Y) / Block_Size_Y;
                            if (tmpY < Pan_Block_Y)
                            {
                                //textBox1.Text = tmpX.ToString();
                                //textBox2.Text = tmpY.ToString();
                                if (dump[tmpX, tmpY].check == true)
                                { bNext = true; break; }

                            }
                            
                        }
                        if(bNext == false) blocks.y += Block_Size_Y;
                        cnt++;
                    }
                        //for (int i = 0; i < BlocksQueue.Peek().floorSize; i++)
                        //{
                        //    if (BlocksQueue.Peek().floorBlockY[i] == Pan_Loc_Y + Pan_Y - Block_Size_Y)
                        //    { bNext = true; }



                        //    int tmpX = BlocksQueue.Peek().floorBlockX[i] / Block_Size_X;
                        //    int tmpY = (BlocksQueue.Peek().floorBlockY[i] + Block_Size_Y) / Block_Size_Y;
                        //    if (tmpY < Pan_Block_Y)
                        //    {
                        //        textBox1.Text = tmpX.ToString();
                        //        textBox2.Text = tmpY.ToString();
                        //        if (dump[tmpX, tmpY].check == true)
                        //        { bNext = true; }

                        //    }
                        //}

                        //switch (BlocksQueue.Peek().floorSize)
                        //{

                        //    case 1:
                        //        if(bNext == true)
                        //        {

                        //        }


                        //        break;
                        //    case 2:




                        //            break;
                        //    case 3:
                        //        break;
                        //    case 4:
                        //        break;

                        //if (BlocksQueue.Peek().floorBlockY == GamePane.Location.Y + Pan_Y - Block_Size_Y)
                        //{
                        //if (bNext == true)
                        //{
                        //    for (int y = 0; y < Pan_Block_Y; y++)
                        //    {
                        //        for (int x = 0; x < Pan_Block_X; x++)
                        //        {
                        //            if ((dump[x, y].X == BlocksList[0].x) && (dump[x, y].Y == BlocksList[0].y))
                        //            {
                        //                for (int i = 0; i < 4; i++)
                        //                {
                        //                    int dumpTmpX = BlocksList[0].block[i].x / Block_Size_X;
                        //                    int dumpTmpY = BlocksList[0].block[i].y / Block_Size_Y;
                        //                    dump[dumpTmpX, dumpTmpY].check = true;
                        //                    dump[dumpTmpX, dumpTmpY].c = BlocksList[0].block[i].c;

                        //                    //textBox1.Text = dumpTmpX.ToString();
                        //                    //textBox2.Text = dumpTmpY.ToString();
                        //                }

                        //            }
                        //        }
                        //    }
                        //    BlocksList.RemoveAt(0);
                        //    //BlocksQueue.Dequeue();
                        //    //bNext = true;
                        //}

                    



                    //blocks.y = Pan_Loc_Y + Pan_Height - blocks.coreblock_height;
                    //for (int i = 0; i < blocks.floorSize; i++)
                    //{
                    //    if (blocks.floorBlockY[i] == Pan_Loc_Y + Pan_Y - Block_Size_Y)
                    //    { blocks.y =  }
                    //}
                    //blocks.y = Pan_Loc_Y + Pan_Y - Block_Size_Y
                    blocks.RefreshBlocksShape();
                    blocks.Draw(_CreateGraphics());
                }
                if (e.KeyCode == Keys.Left)   // 가끔 벽에 안붙으면 멀리서 들이박아야댐..
                {

                    //if (blocks.leftLimitBlock_X > GamePane.Location.X)
                    //{
                    //    blocks.x -= Block_Size_X;
                    //}

                    if (blocks.leftLimitBlock_X > Pan_Loc_X)
                    {
                        blocks.x -= Block_Size_X;
                    }
                    blocks.RefreshBlocksShape();
                    blocks.Draw(_CreateGraphics());
                }
                if (e.KeyCode == Keys.Right)
                {
                    if (blocks.rightLimitBlock_X < Pan_Loc_X + Pan_Width - Block_Size_X) // GamePane.Location.X + Block_Size_X * Pan_Block_X
                    {
                        blocks.x += Block_Size_X;
                    }
                    blocks.RefreshBlocksShape();
                    blocks.Draw(_CreateGraphics());
                }

            }
            _ResumeLayout();
        }

        private void GamePane_Paint_1(object sender, PaintEventArgs e)
        {
            //Graphics g = GamePane.CreateGraphics();
            //for (int x = Block_Size_X; x < GamePane.Width; x += Block_Size_X)
            //{
            //    g.DrawLine(new Pen(Color.Black), new Point(x, 0), new Point(x, GamePane.Height));
            //}
            //for (int y = Block_Size_Y; y < GamePane.Height; y += Block_Size_X)
            //{
            //    g.DrawLine(new Pen(Color.Black), new Point(0, y), new Point(GamePane.Width, y));
            //}
        }

        private void LoopTimer_Tick(object sender, EventArgs e)
        {
            //Invalidate();
            _SuspendLayout();

            int dumpTmpX = 0;
            int dumpTmpY = 0;
            Graphics g = _CreateGraphics();
            Pen dumpPen = new Pen(Color.Black, 5);
            dumpPen.Alignment = System.Drawing.Drawing2D.PenAlignment.Inset;
            //Color c = Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255));

            for (int y = 0; y < Pan_Block_Y; y++)
            {
                for (int x = 0; x < Pan_Block_X; x++)
                {
                    if (dump[x, y].check == true)
                    {
                        dumpTmpX = dump[x, y].X;
                        dumpTmpY = dump[x, y].Y;
                        dumpPen.Color = dump[x, y].c;
                        g.DrawRectangle(dumpPen, new Rectangle(dumpTmpX, dumpTmpY, Block_Size_X, Block_Size_Y));
                    }
                }
            }

            Pen fieldPen = new Pen(Color.Gray, 1);
            fieldPen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            //Graphics g = GamePane.CreateGraphics();
            for (int x = Block_Size_X; x < Pan_Width; x += Block_Size_X)
            {
                g.DrawLine(fieldPen, new Point(x, 0), new Point(x, Pan_Height));
            }
            for (int y = Block_Size_Y; y < Pan_Height; y += Block_Size_X)
            {
                g.DrawLine(fieldPen, new Point(0, y), new Point(Pan_Width, y));
            }
            _ResumeLayout();
        }
    }
}